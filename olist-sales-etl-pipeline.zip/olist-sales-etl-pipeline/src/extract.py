"""Extract step: read the raw CSV files into DataFrames."""
import logging

import pandas as pd

from .config import FILES, RAW_DIR

log = logging.getLogger(__name__)


def extract_all(raw_dir=RAW_DIR):
    """Read every raw CSV and return {table_name: DataFrame}."""
    tables = {}
    for name, filename in FILES.items():
        path = raw_dir / filename
        if not path.exists():
            raise FileNotFoundError(
                f"Missing {path}. Download the Olist dataset from Kaggle and put "
                "the CSVs in data/raw/ (or run `python generate_sample_data.py`)."
            )
        tables[name] = pd.read_csv(path)
        log.info("Extracted %-22s %7d rows", name, len(tables[name]))
    return tables
