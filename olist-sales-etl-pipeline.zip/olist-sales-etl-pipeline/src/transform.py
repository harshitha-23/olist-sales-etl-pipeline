"""Transform step: clean each table and add analysis-ready columns."""
import logging

import pandas as pd

log = logging.getLogger(__name__)

ORDER_DATE_COLS = [
    "order_purchase_timestamp",
    "order_approved_at",
    "order_delivered_carrier_date",
    "order_delivered_customer_date",
    "order_estimated_delivery_date",
]


def _report(table, before, after, reason):
    if before != after:
        log.info("%-15s removed %5d rows (%s)", table, before - after, reason)


def clean_orders(df):
    df = df.copy()

    n = len(df)
    df = df.drop_duplicates(subset="order_id")
    _report("orders", n, len(df), "duplicate order_id")

    for col in ORDER_DATE_COLS:
        df[col] = pd.to_datetime(df[col], errors="coerce")

    n = len(df)
    df = df.dropna(subset=["order_id", "customer_id", "order_purchase_timestamp"])
    _report("orders", n, len(df), "missing id or purchase date")

    df["order_status"] = df["order_status"].astype(str).str.strip().str.lower()

    # A delivery date earlier than the purchase date is impossible -> treat as missing
    bad = df["order_delivered_customer_date"] < df["order_purchase_timestamp"]
    if bad.any():
        log.info("orders          nulled %d impossible delivery dates", int(bad.sum()))
        df.loc[bad, "order_delivered_customer_date"] = pd.NaT

    df["purchase_month"] = df["order_purchase_timestamp"].dt.strftime("%Y-%m")

    # Delivery metrics only make sense for delivered orders with known dates
    delivered = (
        df["order_status"].eq("delivered")
        & df["order_delivered_customer_date"].notna()
        & df["order_estimated_delivery_date"].notna()
    )
    delivery_days = (
        df["order_delivered_customer_date"] - df["order_purchase_timestamp"]
    ).dt.total_seconds() / 86400
    delay_days = (
        df["order_delivered_customer_date"] - df["order_estimated_delivery_date"]
    ).dt.total_seconds() / 86400

    df["delivery_days"] = delivery_days.where(delivered).round(2)
    df["delay_days"] = delay_days.where(delivered).round(2)  # > 0 means late
    df["is_late"] = (df["delay_days"] > 0).astype("float").where(delivered).astype("Int64")
    return df


def clean_items(df, valid_order_ids):
    df = df.copy()

    n = len(df)
    df = df.drop_duplicates(subset=["order_id", "order_item_id"])
    _report("order_items", n, len(df), "duplicate order line")

    df["shipping_limit_date"] = pd.to_datetime(df["shipping_limit_date"], errors="coerce")
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df["freight_value"] = pd.to_numeric(df["freight_value"], errors="coerce").fillna(0)

    n = len(df)
    df = df[df["price"].notna() & (df["price"] >= 0)]
    _report("order_items", n, len(df), "missing or negative price")

    n = len(df)
    df = df[df["order_id"].isin(valid_order_ids)]
    _report("order_items", n, len(df), "order not in orders table")

    df["item_total"] = (df["price"] + df["freight_value"]).round(2)
    return df


def clean_payments(df, valid_order_ids):
    df = df.copy()

    n = len(df)
    df = df.drop_duplicates(subset=["order_id", "payment_sequential"])
    df["payment_value"] = pd.to_numeric(df["payment_value"], errors="coerce")
    df = df[df["payment_value"].notna() & (df["payment_value"] >= 0)]
    df = df[df["order_id"].isin(valid_order_ids)]
    _report("order_payments", n, len(df), "duplicates, bad values, orphan orders")
    return df


def clean_reviews(df, valid_order_ids):
    df = df.copy()
    for col in ["review_creation_date", "review_answer_timestamp"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    df["review_score"] = pd.to_numeric(df["review_score"], errors="coerce")

    n = len(df)
    df = df[df["review_score"].between(1, 5)]
    df = df[df["order_id"].isin(valid_order_ids)]
    _report("order_reviews", n, len(df), "invalid score or orphan order")

    # Keep only the most recent review per order
    n = len(df)
    df = df.sort_values("review_answer_timestamp").drop_duplicates("order_id", keep="last")
    _report("order_reviews", n, len(df), "older review for same order")

    df["review_score"] = df["review_score"].astype(int)
    # free-text comments are dropped on purpose: not needed and may contain personal data
    return df[["review_id", "order_id", "review_score", "review_creation_date"]]


def clean_customers(df):
    df = df.copy()
    n = len(df)
    df = df.drop_duplicates(subset="customer_id")
    _report("customers", n, len(df), "duplicate customer_id")
    df["customer_city"] = df["customer_city"].astype(str).str.strip().str.lower()
    df["customer_state"] = df["customer_state"].astype(str).str.strip().str.upper()
    return df[["customer_id", "customer_unique_id", "customer_city", "customer_state"]]


def clean_products(products, translation):
    df = products.drop_duplicates(subset="product_id").copy()
    tr = translation.drop_duplicates(subset="product_category_name").rename(
        columns={"product_category_name_english": "category_name_english"}
    )
    df = df.merge(tr, on="product_category_name", how="left")
    # English name -> else Portuguese name -> else "unknown"
    df["category_name_english"] = (
        df["category_name_english"].fillna(df["product_category_name"]).fillna("unknown")
    )
    return df[["product_id", "category_name_english", "product_weight_g", "product_photos_qty"]]


def transform_all(raw):
    """Clean all tables. Returns {table_name: DataFrame} ready to load."""
    orders = clean_orders(raw["orders"])
    ids = set(orders["order_id"])
    return {
        "orders": orders,
        "order_items": clean_items(raw["order_items"], ids),
        "order_payments": clean_payments(raw["order_payments"], ids),
        "order_reviews": clean_reviews(raw["order_reviews"], ids),
        "customers": clean_customers(raw["customers"]),
        "products": clean_products(raw["products"], raw["category_translation"]),
    }
