"""Load step: write the cleaned tables into a SQLite database."""
import logging
import sqlite3

import pandas as pd

from .config import DB_PATH

log = logging.getLogger(__name__)

INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id)",
    "CREATE INDEX IF NOT EXISTS idx_orders_month ON orders(purchase_month)",
    "CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id)",
    "CREATE INDEX IF NOT EXISTS idx_items_product ON order_items(product_id)",
    "CREATE INDEX IF NOT EXISTS idx_reviews_order ON order_reviews(order_id)",
    "CREATE INDEX IF NOT EXISTS idx_customers_id ON customers(customer_id)",
]


def load_all(tables, db_path=DB_PATH):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    if db_path.exists():
        db_path.unlink()  # rebuild from scratch so the pipeline is repeatable

    with sqlite3.connect(db_path) as conn:
        for name, df in tables.items():
            out = df.copy()
            # SQLite has no datetime type: store as ISO text so SQL date functions work
            for col in out.columns:
                if pd.api.types.is_datetime64_any_dtype(out[col]):
                    out[col] = out[col].dt.strftime("%Y-%m-%d %H:%M:%S")
            out.to_sql(name, conn, index=False, if_exists="replace")
            log.info("Loaded    %-22s %7d rows", name, len(out))
        for stmt in INDEXES:
            conn.execute(stmt)
    log.info("Database ready: %s", db_path)
