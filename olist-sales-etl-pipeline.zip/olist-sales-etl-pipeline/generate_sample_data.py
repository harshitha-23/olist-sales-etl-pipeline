"""Create SYNTHETIC data in the same format as the Olist Kaggle dataset.

Use this only to test that the pipeline runs before you download the real data.
It includes a few deliberately dirty rows (duplicates, nulls, negative prices)
so you can see the cleaning step working. Do not publish findings from it.
"""
import random
from datetime import datetime, timedelta

import pandas as pd

from src.config import FILES, RAW_DIR

random.seed(42)
N_ORDERS, N_PEOPLE, N_PRODUCTS = 3000, 2400, 200
STATES = {"SP": 0.08, "RJ": 0.14, "MG": 0.10, "RS": 0.12, "PR": 0.10, "BA": 0.25, "SC": 0.09, "PE": 0.22}
CATEGORIES = {
    "cama_mesa_banho": "bed_bath_table",
    "beleza_saude": "health_beauty",
    "esporte_lazer": "sports_leisure",
    "informatica_acessorios": "computers_accessories",
    "moveis_decoracao": "furniture_decor",
    "utilidades_domesticas": "housewares",
    "relogios_presentes": "watches_gifts",
    "brinquedos": "toys",
}


def ts(d):
    return d.strftime("%Y-%m-%d %H:%M:%S") if d else None


def main():
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    start, span_days = datetime(2017, 1, 1), 600

    cats = list(CATEGORIES)
    products = pd.DataFrame(
        {
            "product_id": [f"prod{i:04d}" for i in range(N_PRODUCTS)],
            "product_category_name": [random.choice(cats) if i % 20 else None for i in range(N_PRODUCTS)],
            "product_weight_g": [random.randint(100, 5000) for _ in range(N_PRODUCTS)],
            "product_photos_qty": [random.randint(1, 6) for _ in range(N_PRODUCTS)],
        }
    )
    translation = pd.DataFrame(
        {"product_category_name": list(CATEGORIES), "product_category_name_english": list(CATEGORIES.values())}
    )

    state_list, state_w = list(STATES), list(STATES.values())
    people = [f"person{i:05d}" for i in range(N_PEOPLE)]
    person_state = {p: random.choice(state_list) for p in people}

    orders, customers, items, payments, reviews = [], [], [], [], []
    for n in range(N_ORDERS):
        oid, cid = f"order{n:06d}", f"cust{n:06d}"
        person = random.choice(people)
        purchase = start + timedelta(days=random.random() * span_days, seconds=random.randint(0, 86399))
        status = random.choices(["delivered", "canceled", "shipped"], [0.93, 0.04, 0.03])[0]
        estimated = purchase + timedelta(days=random.randint(12, 30))
        delivered = None
        if status == "delivered":
            late_prob = STATES[person_state[person]]
            if random.random() < late_prob:
                delivered = estimated + timedelta(days=random.randint(1, 15))
            else:
                delivered = max(purchase + timedelta(days=3), estimated - timedelta(days=random.randint(1, 10)))
        orders.append(
            {
                "order_id": oid,
                "customer_id": cid,
                "order_status": status,
                "order_purchase_timestamp": ts(purchase),
                "order_approved_at": ts(purchase + timedelta(hours=1)),
                "order_delivered_carrier_date": ts(purchase + timedelta(days=2)),
                "order_delivered_customer_date": ts(delivered),
                "order_estimated_delivery_date": ts(estimated),
            }
        )
        customers.append(
            {
                "customer_id": cid,
                "customer_unique_id": person,
                "customer_zip_code_prefix": random.randint(10000, 99999),
                "customer_city": " Sao Paulo ",
                "customer_state": person_state[person],
            }
        )
        total = 0.0
        for k in range(1, random.choices([1, 2, 3], [0.8, 0.15, 0.05])[0] + 1):
            price = round(random.uniform(10, 400), 2)
            freight = round(random.uniform(5, 40), 2)
            total += price + freight
            items.append(
                {
                    "order_id": oid,
                    "order_item_id": k,
                    "product_id": random.choice(products["product_id"]),
                    "seller_id": f"seller{random.randint(1, 60):03d}",
                    "shipping_limit_date": ts(purchase + timedelta(days=3)),
                    "price": price,
                    "freight_value": freight,
                }
            )
        payments.append(
            {
                "order_id": oid,
                "payment_sequential": 1,
                "payment_type": random.choice(["credit_card", "boleto", "voucher", "debit_card"]),
                "payment_installments": random.randint(1, 10),
                "payment_value": round(total, 2),
            }
        )
        if delivered and random.random() < 0.95:
            is_late = delivered > estimated
            weights = [30, 20, 20, 15, 15] if is_late else [3, 4, 10, 30, 53]
            reviews.append(
                {
                    "review_id": f"rev{n:06d}",
                    "order_id": oid,
                    "review_score": random.choices([1, 2, 3, 4, 5], weights)[0],
                    "review_comment_title": None,
                    "review_comment_message": None,
                    "review_creation_date": ts(delivered),
                    "review_answer_timestamp": ts(delivered + timedelta(days=1)),
                }
            )

    orders, items, reviews = pd.DataFrame(orders), pd.DataFrame(items), pd.DataFrame(reviews)

    # --- inject dirty data so the cleaning step has something to do ---
    orders = pd.concat([orders, orders.sample(20, random_state=1)], ignore_index=True)       # duplicates
    orders.loc[orders.sample(15, random_state=2).index, "order_purchase_timestamp"] = None   # missing dates
    items.loc[items.sample(5, random_state=3).index, "price"] = -1.0                          # bad prices
    reviews = pd.concat([reviews, reviews.sample(30, random_state=4).assign(review_id=lambda d: "dup" + d["review_id"], review_score=1)])

    data = {
        "orders": orders,
        "order_items": items,
        "order_payments": pd.DataFrame(payments),
        "order_reviews": reviews,
        "customers": pd.DataFrame(customers),
        "products": products,
        "category_translation": translation,
    }
    for name, df in data.items():
        df.to_csv(RAW_DIR / FILES[name], index=False)
        print(f"wrote {FILES[name]:45s} {len(df):6d} rows")


if __name__ == "__main__":
    main()
