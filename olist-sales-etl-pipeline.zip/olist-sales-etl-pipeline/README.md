# Olist Sales ETL Pipeline (Python + SQL)

An end-to-end ETL pipeline that cleans a multi-table e-commerce dataset, loads it into a SQLite database, and answers business questions with SQL (CTEs and window functions).

## Business questions answered
1. How do revenue and average order value change month to month?
2. Which product categories earn the most, and what is the best-selling product in each?
3. Which states have the worst delivery delays?
4. Do late deliveries lower customer review scores?
5. What share of customers buy more than once?

## Pipeline

```
data/raw/*.csv  ->  extract  ->  transform (clean + features)  ->  load  ->  SQLite  ->  sql/*.sql  ->  outputs/*.csv
```

| Step | File | What it does |
|------|------|--------------|
| Extract | `src/extract.py` | Reads the 7 raw CSV files |
| Transform | `src/transform.py` | Removes duplicates, nulls, negative prices and orphan rows; fixes impossible dates; keeps the latest review per order; adds `delivery_days`, `delay_days`, `is_late`, `purchase_month` |
| Load | `src/load.py` | Writes clean tables to SQLite and adds indexes |
| Analyze | `sql/*.sql`, `run_queries.py` | Runs the SQL analysis and saves CSV results |

Every cleaning step logs how many rows it removed, so data quality is visible.

## Data
[Brazilian E-Commerce Public Dataset by Olist](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce) (Kaggle, about 100k orders, 2016-2018). Download it and place these files in `data/raw/`:

```
olist_orders_dataset.csv
olist_order_items_dataset.csv
olist_order_payments_dataset.csv
olist_order_reviews_dataset.csv
olist_customers_dataset.csv
olist_products_dataset.csv
product_category_name_translation.csv
```

## How to run

```bash
pip install -r requirements.txt
python run_pipeline.py     # build data/processed/olist.db
python run_queries.py      # run the SQL analysis, save results to outputs/
python -m pytest           # run the unit tests
```

No dataset yet? `python generate_sample_data.py` creates a small synthetic dataset in the same format so you can test the pipeline. Use the real Kaggle data for any findings you publish.

## Key findings
*Fill this in after running on the real data. Example format:*
- Late deliveries score X points lower in reviews than on-time ones (query 04).
- State X has the highest late rate at Y% (query 03).
- Only Z% of customers place a second order (query 05).

## Skills demonstrated
Python (pandas), ETL design, data cleaning and validation, SQL (joins, CTEs, window functions: `LAG`, `ROW_NUMBER`, `SUM() OVER`), SQLite, unit testing (pytest), logging, project structure and documentation.

## Project structure
```
.
├── run_pipeline.py
├── run_queries.py
├── generate_sample_data.py
├── src/            extract.py, transform.py, load.py, config.py
├── sql/            five analysis queries
├── tests/          unit tests for the transform step
├── data/raw/       put the Kaggle CSVs here (git-ignored)
├── data/processed/ SQLite database (git-ignored)
└── outputs/        query results as CSV
```
