import pandas as pd

from src.transform import clean_items, clean_orders, clean_reviews


def _orders():
    return pd.DataFrame(
        {
            "order_id": ["a", "a", "b", "c"],
            "customer_id": ["c1", "c1", "c2", "c3"],
            "order_status": ["delivered", "delivered", " Delivered ", "canceled"],
            "order_purchase_timestamp": ["2018-01-01 10:00:00"] * 3 + [None],
            "order_approved_at": [None] * 4,
            "order_delivered_carrier_date": [None] * 4,
            "order_delivered_customer_date": [
                "2018-01-12 10:00:00",
                "2018-01-12 10:00:00",
                "2018-01-05 10:00:00",
                None,
            ],
            "order_estimated_delivery_date": [
                "2018-01-10 10:00:00",
                "2018-01-10 10:00:00",
                "2018-01-10 10:00:00",
                None,
            ],
        }
    )


def test_orders_duplicates_and_missing_dates_removed():
    out = clean_orders(_orders())
    assert sorted(out["order_id"]) == ["a", "b"]


def test_orders_late_flag_and_status_cleaning():
    out = clean_orders(_orders()).set_index("order_id")
    assert out.loc["a", "is_late"] == 1  # delivered 2 days after estimate
    assert out.loc["b", "is_late"] == 0  # delivered 5 days early
    assert out.loc["b", "order_status"] == "delivered"
    assert out.loc["a", "delay_days"] == 2.0


def test_items_negative_price_and_orphans_removed():
    items = pd.DataFrame(
        {
            "order_id": ["a", "a", "zzz"],
            "order_item_id": [1, 2, 1],
            "product_id": ["p1", "p2", "p3"],
            "shipping_limit_date": ["2018-01-03 00:00:00"] * 3,
            "price": [10.0, -5.0, 20.0],
            "freight_value": [2.0, 1.0, 3.0],
        }
    )
    out = clean_items(items, valid_order_ids={"a"})
    assert list(out["product_id"]) == ["p1"]
    assert out.iloc[0]["item_total"] == 12.0


def test_reviews_keep_latest_per_order():
    reviews = pd.DataFrame(
        {
            "review_id": ["r1", "r2", "r3"],
            "order_id": ["a", "a", "b"],
            "review_score": [1, 5, 9],  # 9 is invalid
            "review_creation_date": ["2018-02-01"] * 3,
            "review_answer_timestamp": ["2018-02-02", "2018-02-05", "2018-02-03"],
        }
    )
    out = clean_reviews(reviews, valid_order_ids={"a", "b"})
    assert list(out["order_id"]) == ["a"]
    assert out.iloc[0]["review_score"] == 5
