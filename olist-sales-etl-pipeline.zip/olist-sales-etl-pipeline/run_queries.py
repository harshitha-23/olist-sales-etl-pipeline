"""Run every .sql file in sql/ against the database; print and save results as CSV."""
import sqlite3

import pandas as pd

from src.config import DB_PATH, OUTPUT_DIR, SQL_DIR


def main():
    if not DB_PATH.exists():
        raise SystemExit("Database not found. Run `python run_pipeline.py` first.")
    OUTPUT_DIR.mkdir(exist_ok=True)
    pd.set_option("display.width", 120)
    pd.set_option("display.max_columns", 20)

    with sqlite3.connect(DB_PATH) as conn:
        for sql_file in sorted(SQL_DIR.glob("*.sql")):
            result = pd.read_sql_query(sql_file.read_text(), conn)
            result.to_csv(OUTPUT_DIR / f"{sql_file.stem}.csv", index=False)
            print(f"\n=== {sql_file.stem} ===")
            print(result.head(15).to_string(index=False))


if __name__ == "__main__":
    main()
