-- Top 10 categories by revenue, with the best-selling product in each
-- Techniques: multi-join, CTEs, SUM() OVER (PARTITION BY), ROW_NUMBER()
WITH product_sales AS (
    SELECT p.category_name_english AS category,
           i.product_id,
           COUNT(*)                AS units_sold,
           ROUND(SUM(i.price), 2)  AS revenue
    FROM order_items i
    JOIN orders   o ON o.order_id = i.order_id AND o.order_status = 'delivered'
    JOIN products p ON p.product_id = i.product_id
    GROUP BY p.category_name_english, i.product_id
),
ranked AS (
    SELECT *,
           SUM(revenue) OVER (PARTITION BY category) AS category_revenue,
           ROW_NUMBER() OVER (PARTITION BY category ORDER BY revenue DESC) AS rank_in_category
    FROM product_sales
)
SELECT category,
       ROUND(category_revenue, 2) AS category_revenue,
       product_id                 AS top_product_id,
       units_sold                 AS top_product_units,
       revenue                    AS top_product_revenue
FROM ranked
WHERE rank_in_category = 1
ORDER BY category_revenue DESC
LIMIT 10;
