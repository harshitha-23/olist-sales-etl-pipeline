-- Monthly revenue, average order value, month-over-month growth, running total
-- Techniques: CTE, LAG(), running SUM() window
WITH monthly AS (
    SELECT o.purchase_month                  AS month,
           COUNT(DISTINCT o.order_id)        AS orders,
           ROUND(SUM(i.price), 2)            AS revenue
    FROM orders o
    JOIN order_items i ON i.order_id = o.order_id
    WHERE o.order_status = 'delivered'
    GROUP BY o.purchase_month
)
SELECT month,
       orders,
       revenue,
       ROUND(revenue * 1.0 / orders, 2) AS avg_order_value,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
             / LAG(revenue) OVER (ORDER BY month), 1) AS mom_growth_pct,
       ROUND(SUM(revenue) OVER (ORDER BY month), 2) AS cumulative_revenue
FROM monthly
ORDER BY month;
