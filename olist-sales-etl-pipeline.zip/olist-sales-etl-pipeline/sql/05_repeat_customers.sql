-- Repeat purchase rate (customer_unique_id identifies a real person)
-- Techniques: ROW_NUMBER() OVER (PARTITION BY ...), CTEs, conditional aggregation
WITH customer_orders AS (
    SELECT c.customer_unique_id,
           o.order_id,
           ROW_NUMBER() OVER (
               PARTITION BY c.customer_unique_id
               ORDER BY o.order_purchase_timestamp
           ) AS order_number
    FROM orders o
    JOIN customers c ON c.customer_id = o.customer_id
    WHERE o.order_status = 'delivered'
),
per_customer AS (
    SELECT customer_unique_id, MAX(order_number) AS total_orders
    FROM customer_orders
    GROUP BY customer_unique_id
)
SELECT COUNT(*)                                             AS customers,
       SUM(CASE WHEN total_orders > 1 THEN 1 ELSE 0 END)    AS repeat_customers,
       ROUND(100.0 * SUM(CASE WHEN total_orders > 1 THEN 1 ELSE 0 END) / COUNT(*), 2) AS repeat_rate_pct
FROM per_customer;
