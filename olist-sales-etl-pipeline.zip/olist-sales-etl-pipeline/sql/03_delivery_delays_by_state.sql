-- Delivery performance by customer state (states with at least 10 delivered orders)
SELECT c.customer_state                                   AS state,
       COUNT(*)                                           AS delivered_orders,
       ROUND(AVG(o.delivery_days), 1)                     AS avg_delivery_days,
       ROUND(100.0 * AVG(o.is_late), 1)                   AS late_rate_pct,
       ROUND(AVG(CASE WHEN o.is_late = 1 THEN o.delay_days END), 1) AS avg_days_late_when_late
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
WHERE o.order_status = 'delivered'
  AND o.is_late IS NOT NULL
GROUP BY c.customer_state
HAVING COUNT(*) >= 10
ORDER BY late_rate_pct DESC;
