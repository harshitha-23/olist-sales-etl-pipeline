"""Run the full ETL: raw CSVs -> cleaned tables -> SQLite database."""
import logging

from src.extract import extract_all
from src.load import load_all
from src.transform import transform_all


def main():
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    raw = extract_all()
    clean = transform_all(raw)
    load_all(clean)


if __name__ == "__main__":
    main()
